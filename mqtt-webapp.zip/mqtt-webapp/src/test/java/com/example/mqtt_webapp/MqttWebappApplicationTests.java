package com.example.mqtt_webapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MqttWebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
